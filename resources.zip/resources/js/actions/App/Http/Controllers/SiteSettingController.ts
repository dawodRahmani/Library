import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SiteSettingController::adminIndex
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
export const adminIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})

adminIndex.definition = {
    methods: ["get","head"],
    url: '/admin/site-settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteSettingController::adminIndex
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
adminIndex.url = (options?: RouteQueryOptions) => {
    return adminIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::adminIndex
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
adminIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteSettingController::adminIndex
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
adminIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::adminIndex
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
    const adminIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::adminIndex
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
        adminIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteSettingController::adminIndex
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
        adminIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminIndex.form = adminIndexForm
/**
* @see \App\Http\Controllers\SiteSettingController::bulkUpdate
 * @see app/Http/Controllers/SiteSettingController.php:22
 * @route '/admin/site-settings'
 */
export const bulkUpdate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkUpdate.url(options),
    method: 'post',
})

bulkUpdate.definition = {
    methods: ["post"],
    url: '/admin/site-settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SiteSettingController::bulkUpdate
 * @see app/Http/Controllers/SiteSettingController.php:22
 * @route '/admin/site-settings'
 */
bulkUpdate.url = (options?: RouteQueryOptions) => {
    return bulkUpdate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::bulkUpdate
 * @see app/Http/Controllers/SiteSettingController.php:22
 * @route '/admin/site-settings'
 */
bulkUpdate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkUpdate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::bulkUpdate
 * @see app/Http/Controllers/SiteSettingController.php:22
 * @route '/admin/site-settings'
 */
    const bulkUpdateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkUpdate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::bulkUpdate
 * @see app/Http/Controllers/SiteSettingController.php:22
 * @route '/admin/site-settings'
 */
        bulkUpdateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkUpdate.url(options),
            method: 'post',
        })
    
    bulkUpdate.form = bulkUpdateForm
/**
* @see \App\Http\Controllers\SiteSettingController::uploadLogo
 * @see app/Http/Controllers/SiteSettingController.php:98
 * @route '/admin/site-settings/logo'
 */
export const uploadLogo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadLogo.url(options),
    method: 'post',
})

uploadLogo.definition = {
    methods: ["post"],
    url: '/admin/site-settings/logo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SiteSettingController::uploadLogo
 * @see app/Http/Controllers/SiteSettingController.php:98
 * @route '/admin/site-settings/logo'
 */
uploadLogo.url = (options?: RouteQueryOptions) => {
    return uploadLogo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::uploadLogo
 * @see app/Http/Controllers/SiteSettingController.php:98
 * @route '/admin/site-settings/logo'
 */
uploadLogo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadLogo.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::uploadLogo
 * @see app/Http/Controllers/SiteSettingController.php:98
 * @route '/admin/site-settings/logo'
 */
    const uploadLogoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: uploadLogo.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::uploadLogo
 * @see app/Http/Controllers/SiteSettingController.php:98
 * @route '/admin/site-settings/logo'
 */
        uploadLogoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: uploadLogo.url(options),
            method: 'post',
        })
    
    uploadLogo.form = uploadLogoForm
/**
* @see \App\Http\Controllers\SiteSettingController::removeLogo
 * @see app/Http/Controllers/SiteSettingController.php:114
 * @route '/admin/site-settings/logo'
 */
export const removeLogo = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeLogo.url(options),
    method: 'delete',
})

removeLogo.definition = {
    methods: ["delete"],
    url: '/admin/site-settings/logo',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SiteSettingController::removeLogo
 * @see app/Http/Controllers/SiteSettingController.php:114
 * @route '/admin/site-settings/logo'
 */
removeLogo.url = (options?: RouteQueryOptions) => {
    return removeLogo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::removeLogo
 * @see app/Http/Controllers/SiteSettingController.php:114
 * @route '/admin/site-settings/logo'
 */
removeLogo.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeLogo.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::removeLogo
 * @see app/Http/Controllers/SiteSettingController.php:114
 * @route '/admin/site-settings/logo'
 */
    const removeLogoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: removeLogo.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::removeLogo
 * @see app/Http/Controllers/SiteSettingController.php:114
 * @route '/admin/site-settings/logo'
 */
        removeLogoForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: removeLogo.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    removeLogo.form = removeLogoForm
/**
* @see \App\Http\Controllers\SiteSettingController::uploadContactQr
 * @see app/Http/Controllers/SiteSettingController.php:124
 * @route '/admin/site-settings/contact-qr'
 */
export const uploadContactQr = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadContactQr.url(options),
    method: 'post',
})

uploadContactQr.definition = {
    methods: ["post"],
    url: '/admin/site-settings/contact-qr',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SiteSettingController::uploadContactQr
 * @see app/Http/Controllers/SiteSettingController.php:124
 * @route '/admin/site-settings/contact-qr'
 */
uploadContactQr.url = (options?: RouteQueryOptions) => {
    return uploadContactQr.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::uploadContactQr
 * @see app/Http/Controllers/SiteSettingController.php:124
 * @route '/admin/site-settings/contact-qr'
 */
uploadContactQr.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadContactQr.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::uploadContactQr
 * @see app/Http/Controllers/SiteSettingController.php:124
 * @route '/admin/site-settings/contact-qr'
 */
    const uploadContactQrForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: uploadContactQr.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::uploadContactQr
 * @see app/Http/Controllers/SiteSettingController.php:124
 * @route '/admin/site-settings/contact-qr'
 */
        uploadContactQrForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: uploadContactQr.url(options),
            method: 'post',
        })
    
    uploadContactQr.form = uploadContactQrForm
/**
* @see \App\Http\Controllers\SiteSettingController::removeContactQr
 * @see app/Http/Controllers/SiteSettingController.php:142
 * @route '/admin/site-settings/contact-qr'
 */
export const removeContactQr = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeContactQr.url(options),
    method: 'delete',
})

removeContactQr.definition = {
    methods: ["delete"],
    url: '/admin/site-settings/contact-qr',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SiteSettingController::removeContactQr
 * @see app/Http/Controllers/SiteSettingController.php:142
 * @route '/admin/site-settings/contact-qr'
 */
removeContactQr.url = (options?: RouteQueryOptions) => {
    return removeContactQr.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::removeContactQr
 * @see app/Http/Controllers/SiteSettingController.php:142
 * @route '/admin/site-settings/contact-qr'
 */
removeContactQr.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeContactQr.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::removeContactQr
 * @see app/Http/Controllers/SiteSettingController.php:142
 * @route '/admin/site-settings/contact-qr'
 */
    const removeContactQrForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: removeContactQr.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::removeContactQr
 * @see app/Http/Controllers/SiteSettingController.php:142
 * @route '/admin/site-settings/contact-qr'
 */
        removeContactQrForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: removeContactQr.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    removeContactQr.form = removeContactQrForm
/**
* @see \App\Http\Controllers\SiteSettingController::uploadAboutHero
 * @see app/Http/Controllers/SiteSettingController.php:155
 * @route '/admin/site-settings/about-hero'
 */
export const uploadAboutHero = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadAboutHero.url(options),
    method: 'post',
})

uploadAboutHero.definition = {
    methods: ["post"],
    url: '/admin/site-settings/about-hero',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SiteSettingController::uploadAboutHero
 * @see app/Http/Controllers/SiteSettingController.php:155
 * @route '/admin/site-settings/about-hero'
 */
uploadAboutHero.url = (options?: RouteQueryOptions) => {
    return uploadAboutHero.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::uploadAboutHero
 * @see app/Http/Controllers/SiteSettingController.php:155
 * @route '/admin/site-settings/about-hero'
 */
uploadAboutHero.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadAboutHero.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::uploadAboutHero
 * @see app/Http/Controllers/SiteSettingController.php:155
 * @route '/admin/site-settings/about-hero'
 */
    const uploadAboutHeroForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: uploadAboutHero.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::uploadAboutHero
 * @see app/Http/Controllers/SiteSettingController.php:155
 * @route '/admin/site-settings/about-hero'
 */
        uploadAboutHeroForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: uploadAboutHero.url(options),
            method: 'post',
        })
    
    uploadAboutHero.form = uploadAboutHeroForm
/**
* @see \App\Http\Controllers\SiteSettingController::removeAboutHero
 * @see app/Http/Controllers/SiteSettingController.php:173
 * @route '/admin/site-settings/about-hero'
 */
export const removeAboutHero = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeAboutHero.url(options),
    method: 'delete',
})

removeAboutHero.definition = {
    methods: ["delete"],
    url: '/admin/site-settings/about-hero',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SiteSettingController::removeAboutHero
 * @see app/Http/Controllers/SiteSettingController.php:173
 * @route '/admin/site-settings/about-hero'
 */
removeAboutHero.url = (options?: RouteQueryOptions) => {
    return removeAboutHero.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::removeAboutHero
 * @see app/Http/Controllers/SiteSettingController.php:173
 * @route '/admin/site-settings/about-hero'
 */
removeAboutHero.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeAboutHero.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::removeAboutHero
 * @see app/Http/Controllers/SiteSettingController.php:173
 * @route '/admin/site-settings/about-hero'
 */
    const removeAboutHeroForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: removeAboutHero.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::removeAboutHero
 * @see app/Http/Controllers/SiteSettingController.php:173
 * @route '/admin/site-settings/about-hero'
 */
        removeAboutHeroForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: removeAboutHero.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    removeAboutHero.form = removeAboutHeroForm
const SiteSettingController = { adminIndex, bulkUpdate, uploadLogo, removeLogo, uploadContactQr, removeContactQr, uploadAboutHero, removeAboutHero }

export default SiteSettingController