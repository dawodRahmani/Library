import SearchController from './SearchController'
import HomeController from './HomeController'
import BookController from './BookController'
import VideoController from './VideoController'
import AudioController from './AudioController'
import FatwaController from './FatwaController'
import MagazineController from './MagazineController'
import StatementController from './StatementController'
import ContactController from './ContactController'
import DashboardController from './DashboardController'
import UserController from './UserController'
import SiteSettingController from './SiteSettingController'
import BackupController from './BackupController'
import CategoryController from './CategoryController'
import Settings from './Settings'
const Controllers = {
    SearchController: Object.assign(SearchController, SearchController),
HomeController: Object.assign(HomeController, HomeController),
BookController: Object.assign(BookController, BookController),
VideoController: Object.assign(VideoController, VideoController),
AudioController: Object.assign(AudioController, AudioController),
FatwaController: Object.assign(FatwaController, FatwaController),
MagazineController: Object.assign(MagazineController, MagazineController),
StatementController: Object.assign(StatementController, StatementController),
ContactController: Object.assign(ContactController, ContactController),
DashboardController: Object.assign(DashboardController, DashboardController),
UserController: Object.assign(UserController, UserController),
SiteSettingController: Object.assign(SiteSettingController, SiteSettingController),
BackupController: Object.assign(BackupController, BackupController),
CategoryController: Object.assign(CategoryController, CategoryController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers