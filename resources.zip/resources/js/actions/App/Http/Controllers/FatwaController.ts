import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dar-ul-ifta',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
export const stream = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})

stream.definition = {
    methods: ["get","head"],
    url: '/dar-ul-ifta/{fatwa}/stream',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
stream.url = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fatwa: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fatwa: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fatwa: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fatwa: typeof args.fatwa === 'object'
                ? args.fatwa.id
                : args.fatwa,
                }

    return stream.definition.url
            .replace('{fatwa}', parsedArgs.fatwa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
stream.get = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
stream.head = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stream.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
    const streamForm = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stream.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
        streamForm.get = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
        streamForm.head = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stream.form = streamForm
/**
* @see \App\Http\Controllers\FatwaController::adminIndex
 * @see app/Http/Controllers/FatwaController.php:114
 * @route '/admin/fatwas'
 */
export const adminIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})

adminIndex.definition = {
    methods: ["get","head"],
    url: '/admin/fatwas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FatwaController::adminIndex
 * @see app/Http/Controllers/FatwaController.php:114
 * @route '/admin/fatwas'
 */
adminIndex.url = (options?: RouteQueryOptions) => {
    return adminIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::adminIndex
 * @see app/Http/Controllers/FatwaController.php:114
 * @route '/admin/fatwas'
 */
adminIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FatwaController::adminIndex
 * @see app/Http/Controllers/FatwaController.php:114
 * @route '/admin/fatwas'
 */
adminIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FatwaController::adminIndex
 * @see app/Http/Controllers/FatwaController.php:114
 * @route '/admin/fatwas'
 */
    const adminIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FatwaController::adminIndex
 * @see app/Http/Controllers/FatwaController.php:114
 * @route '/admin/fatwas'
 */
        adminIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FatwaController::adminIndex
 * @see app/Http/Controllers/FatwaController.php:114
 * @route '/admin/fatwas'
 */
        adminIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminIndex.form = adminIndexForm
/**
* @see \App\Http\Controllers\FatwaController::store
 * @see app/Http/Controllers/FatwaController.php:150
 * @route '/admin/fatwas'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/fatwas',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FatwaController::store
 * @see app/Http/Controllers/FatwaController.php:150
 * @route '/admin/fatwas'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::store
 * @see app/Http/Controllers/FatwaController.php:150
 * @route '/admin/fatwas'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FatwaController::store
 * @see app/Http/Controllers/FatwaController.php:150
 * @route '/admin/fatwas'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FatwaController::store
 * @see app/Http/Controllers/FatwaController.php:150
 * @route '/admin/fatwas'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\FatwaController::update
 * @see app/Http/Controllers/FatwaController.php:157
 * @route '/admin/fatwas/{fatwa}'
 */
export const update = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/fatwas/{fatwa}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FatwaController::update
 * @see app/Http/Controllers/FatwaController.php:157
 * @route '/admin/fatwas/{fatwa}'
 */
update.url = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fatwa: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fatwa: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fatwa: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fatwa: typeof args.fatwa === 'object'
                ? args.fatwa.id
                : args.fatwa,
                }

    return update.definition.url
            .replace('{fatwa}', parsedArgs.fatwa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::update
 * @see app/Http/Controllers/FatwaController.php:157
 * @route '/admin/fatwas/{fatwa}'
 */
update.put = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\FatwaController::update
 * @see app/Http/Controllers/FatwaController.php:157
 * @route '/admin/fatwas/{fatwa}'
 */
    const updateForm = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FatwaController::update
 * @see app/Http/Controllers/FatwaController.php:157
 * @route '/admin/fatwas/{fatwa}'
 */
        updateForm.put = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\FatwaController::destroy
 * @see app/Http/Controllers/FatwaController.php:245
 * @route '/admin/fatwas/{fatwa}'
 */
export const destroy = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/fatwas/{fatwa}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\FatwaController::destroy
 * @see app/Http/Controllers/FatwaController.php:245
 * @route '/admin/fatwas/{fatwa}'
 */
destroy.url = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fatwa: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fatwa: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fatwa: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fatwa: typeof args.fatwa === 'object'
                ? args.fatwa.id
                : args.fatwa,
                }

    return destroy.definition.url
            .replace('{fatwa}', parsedArgs.fatwa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::destroy
 * @see app/Http/Controllers/FatwaController.php:245
 * @route '/admin/fatwas/{fatwa}'
 */
destroy.delete = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\FatwaController::destroy
 * @see app/Http/Controllers/FatwaController.php:245
 * @route '/admin/fatwas/{fatwa}'
 */
    const destroyForm = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FatwaController::destroy
 * @see app/Http/Controllers/FatwaController.php:245
 * @route '/admin/fatwas/{fatwa}'
 */
        destroyForm.delete = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const FatwaController = { index, stream, adminIndex, store, update, destroy }

export default FatwaController