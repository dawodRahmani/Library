import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/majalla',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
export const reader = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reader.url(args, options),
    method: 'get',
})

reader.definition = {
    methods: ["get","head"],
    url: '/majalla/{magazine}/reader',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
reader.url = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { magazine: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { magazine: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    magazine: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        magazine: typeof args.magazine === 'object'
                ? args.magazine.id
                : args.magazine,
                }

    return reader.definition.url
            .replace('{magazine}', parsedArgs.magazine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
reader.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reader.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
reader.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reader.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
    const readerForm = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reader.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
        readerForm.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reader.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
        readerForm.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reader.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reader.form = readerForm
/**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
export const read = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: read.url(args, options),
    method: 'get',
})

read.definition = {
    methods: ["get","head"],
    url: '/majalla/{magazine}/read',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
read.url = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { magazine: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { magazine: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    magazine: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        magazine: typeof args.magazine === 'object'
                ? args.magazine.id
                : args.magazine,
                }

    return read.definition.url
            .replace('{magazine}', parsedArgs.magazine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
read.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: read.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
read.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: read.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
    const readForm = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: read.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
        readForm.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: read.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
        readForm.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: read.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    read.form = readForm
/**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
export const download = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/majalla/{magazine}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
download.url = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { magazine: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { magazine: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    magazine: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        magazine: typeof args.magazine === 'object'
                ? args.magazine.id
                : args.magazine,
                }

    return download.definition.url
            .replace('{magazine}', parsedArgs.magazine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
download.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
download.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
    const downloadForm = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
        downloadForm.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
        downloadForm.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
/**
* @see \App\Http\Controllers\MagazineController::adminIndex
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
export const adminIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})

adminIndex.definition = {
    methods: ["get","head"],
    url: '/admin/magazines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MagazineController::adminIndex
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
adminIndex.url = (options?: RouteQueryOptions) => {
    return adminIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::adminIndex
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
adminIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MagazineController::adminIndex
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
adminIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MagazineController::adminIndex
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
    const adminIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MagazineController::adminIndex
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
        adminIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MagazineController::adminIndex
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
        adminIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminIndex.form = adminIndexForm
/**
* @see \App\Http\Controllers\MagazineController::store
 * @see app/Http/Controllers/MagazineController.php:133
 * @route '/admin/magazines'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/magazines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MagazineController::store
 * @see app/Http/Controllers/MagazineController.php:133
 * @route '/admin/magazines'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::store
 * @see app/Http/Controllers/MagazineController.php:133
 * @route '/admin/magazines'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MagazineController::store
 * @see app/Http/Controllers/MagazineController.php:133
 * @route '/admin/magazines'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MagazineController::store
 * @see app/Http/Controllers/MagazineController.php:133
 * @route '/admin/magazines'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\MagazineController::update
 * @see app/Http/Controllers/MagazineController.php:140
 * @route '/admin/magazines/{magazine}'
 */
export const update = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/magazines/{magazine}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\MagazineController::update
 * @see app/Http/Controllers/MagazineController.php:140
 * @route '/admin/magazines/{magazine}'
 */
update.url = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { magazine: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { magazine: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    magazine: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        magazine: typeof args.magazine === 'object'
                ? args.magazine.id
                : args.magazine,
                }

    return update.definition.url
            .replace('{magazine}', parsedArgs.magazine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::update
 * @see app/Http/Controllers/MagazineController.php:140
 * @route '/admin/magazines/{magazine}'
 */
update.put = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\MagazineController::update
 * @see app/Http/Controllers/MagazineController.php:140
 * @route '/admin/magazines/{magazine}'
 */
    const updateForm = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MagazineController::update
 * @see app/Http/Controllers/MagazineController.php:140
 * @route '/admin/magazines/{magazine}'
 */
        updateForm.put = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\MagazineController::destroy
 * @see app/Http/Controllers/MagazineController.php:147
 * @route '/admin/magazines/{magazine}'
 */
export const destroy = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/magazines/{magazine}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\MagazineController::destroy
 * @see app/Http/Controllers/MagazineController.php:147
 * @route '/admin/magazines/{magazine}'
 */
destroy.url = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { magazine: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { magazine: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    magazine: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        magazine: typeof args.magazine === 'object'
                ? args.magazine.id
                : args.magazine,
                }

    return destroy.definition.url
            .replace('{magazine}', parsedArgs.magazine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::destroy
 * @see app/Http/Controllers/MagazineController.php:147
 * @route '/admin/magazines/{magazine}'
 */
destroy.delete = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\MagazineController::destroy
 * @see app/Http/Controllers/MagazineController.php:147
 * @route '/admin/magazines/{magazine}'
 */
    const destroyForm = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MagazineController::destroy
 * @see app/Http/Controllers/MagazineController.php:147
 * @route '/admin/magazines/{magazine}'
 */
        destroyForm.delete = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const MagazineController = { index, reader, read, download, adminIndex, store, update, destroy }

export default MagazineController