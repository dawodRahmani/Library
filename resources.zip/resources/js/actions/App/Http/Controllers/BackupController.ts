import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\BackupController::downloadDatabase
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
export const downloadDatabase = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDatabase.url(options),
    method: 'get',
})

downloadDatabase.definition = {
    methods: ["get","head"],
    url: '/admin/backup/database',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BackupController::downloadDatabase
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
downloadDatabase.url = (options?: RouteQueryOptions) => {
    return downloadDatabase.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BackupController::downloadDatabase
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
downloadDatabase.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadDatabase.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BackupController::downloadDatabase
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
downloadDatabase.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadDatabase.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BackupController::downloadDatabase
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
    const downloadDatabaseForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadDatabase.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BackupController::downloadDatabase
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
        downloadDatabaseForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadDatabase.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BackupController::downloadDatabase
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
        downloadDatabaseForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadDatabase.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadDatabase.form = downloadDatabaseForm
/**
* @see \App\Http\Controllers\BackupController::downloadImages
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
export const downloadImages = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadImages.url(options),
    method: 'get',
})

downloadImages.definition = {
    methods: ["get","head"],
    url: '/admin/backup/images',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BackupController::downloadImages
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
downloadImages.url = (options?: RouteQueryOptions) => {
    return downloadImages.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BackupController::downloadImages
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
downloadImages.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadImages.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BackupController::downloadImages
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
downloadImages.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadImages.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BackupController::downloadImages
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
    const downloadImagesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadImages.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BackupController::downloadImages
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
        downloadImagesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadImages.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BackupController::downloadImages
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
        downloadImagesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadImages.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadImages.form = downloadImagesForm
/**
* @see \App\Http\Controllers\BackupController::downloadVideos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
export const downloadVideos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadVideos.url(options),
    method: 'get',
})

downloadVideos.definition = {
    methods: ["get","head"],
    url: '/admin/backup/videos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BackupController::downloadVideos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
downloadVideos.url = (options?: RouteQueryOptions) => {
    return downloadVideos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BackupController::downloadVideos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
downloadVideos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadVideos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BackupController::downloadVideos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
downloadVideos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadVideos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BackupController::downloadVideos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
    const downloadVideosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadVideos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BackupController::downloadVideos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
        downloadVideosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadVideos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BackupController::downloadVideos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
        downloadVideosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadVideos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadVideos.form = downloadVideosForm
const BackupController = { downloadDatabase, downloadImages, downloadVideos }

export default BackupController