import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import books from './books'
import videos3b3162 from './videos'
/**
* @see \App\Http\Controllers\BookController::index
 * @see app/Http/Controllers/BookController.php:18
 * @route '/library'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/library',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BookController::index
 * @see app/Http/Controllers/BookController.php:18
 * @route '/library'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BookController::index
 * @see app/Http/Controllers/BookController.php:18
 * @route '/library'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BookController::index
 * @see app/Http/Controllers/BookController.php:18
 * @route '/library'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BookController::index
 * @see app/Http/Controllers/BookController.php:18
 * @route '/library'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BookController::index
 * @see app/Http/Controllers/BookController.php:18
 * @route '/library'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BookController::index
 * @see app/Http/Controllers/BookController.php:18
 * @route '/library'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\VideoController::videos
 * @see app/Http/Controllers/VideoController.php:18
 * @route '/library/videos'
 */
export const videos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: videos.url(options),
    method: 'get',
})

videos.definition = {
    methods: ["get","head"],
    url: '/library/videos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\VideoController::videos
 * @see app/Http/Controllers/VideoController.php:18
 * @route '/library/videos'
 */
videos.url = (options?: RouteQueryOptions) => {
    return videos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\VideoController::videos
 * @see app/Http/Controllers/VideoController.php:18
 * @route '/library/videos'
 */
videos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: videos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\VideoController::videos
 * @see app/Http/Controllers/VideoController.php:18
 * @route '/library/videos'
 */
videos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: videos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\VideoController::videos
 * @see app/Http/Controllers/VideoController.php:18
 * @route '/library/videos'
 */
    const videosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: videos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\VideoController::videos
 * @see app/Http/Controllers/VideoController.php:18
 * @route '/library/videos'
 */
        videosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: videos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\VideoController::videos
 * @see app/Http/Controllers/VideoController.php:18
 * @route '/library/videos'
 */
        videosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: videos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    videos.form = videosForm
const library = {
    index: Object.assign(index, index),
books: Object.assign(books, books),
videos: Object.assign(videos, videos3b3162),
}

export default library