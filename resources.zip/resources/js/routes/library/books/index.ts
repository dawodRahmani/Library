import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\BookController::reader
 * @see app/Http/Controllers/BookController.php:67
 * @route '/library/books/{book}/reader'
 */
export const reader = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reader.url(args, options),
    method: 'get',
})

reader.definition = {
    methods: ["get","head"],
    url: '/library/books/{book}/reader',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BookController::reader
 * @see app/Http/Controllers/BookController.php:67
 * @route '/library/books/{book}/reader'
 */
reader.url = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { book: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    book: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book: typeof args.book === 'object'
                ? args.book.id
                : args.book,
                }

    return reader.definition.url
            .replace('{book}', parsedArgs.book.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BookController::reader
 * @see app/Http/Controllers/BookController.php:67
 * @route '/library/books/{book}/reader'
 */
reader.get = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reader.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BookController::reader
 * @see app/Http/Controllers/BookController.php:67
 * @route '/library/books/{book}/reader'
 */
reader.head = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reader.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BookController::reader
 * @see app/Http/Controllers/BookController.php:67
 * @route '/library/books/{book}/reader'
 */
    const readerForm = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reader.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BookController::reader
 * @see app/Http/Controllers/BookController.php:67
 * @route '/library/books/{book}/reader'
 */
        readerForm.get = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reader.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BookController::reader
 * @see app/Http/Controllers/BookController.php:67
 * @route '/library/books/{book}/reader'
 */
        readerForm.head = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reader.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reader.form = readerForm
/**
* @see \App\Http\Controllers\BookController::read
 * @see app/Http/Controllers/BookController.php:90
 * @route '/library/books/{book}/read'
 */
export const read = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: read.url(args, options),
    method: 'get',
})

read.definition = {
    methods: ["get","head"],
    url: '/library/books/{book}/read',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BookController::read
 * @see app/Http/Controllers/BookController.php:90
 * @route '/library/books/{book}/read'
 */
read.url = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { book: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    book: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book: typeof args.book === 'object'
                ? args.book.id
                : args.book,
                }

    return read.definition.url
            .replace('{book}', parsedArgs.book.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BookController::read
 * @see app/Http/Controllers/BookController.php:90
 * @route '/library/books/{book}/read'
 */
read.get = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: read.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BookController::read
 * @see app/Http/Controllers/BookController.php:90
 * @route '/library/books/{book}/read'
 */
read.head = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: read.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BookController::read
 * @see app/Http/Controllers/BookController.php:90
 * @route '/library/books/{book}/read'
 */
    const readForm = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: read.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BookController::read
 * @see app/Http/Controllers/BookController.php:90
 * @route '/library/books/{book}/read'
 */
        readForm.get = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: read.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BookController::read
 * @see app/Http/Controllers/BookController.php:90
 * @route '/library/books/{book}/read'
 */
        readForm.head = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: read.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    read.form = readForm
/**
* @see \App\Http\Controllers\BookController::download
 * @see app/Http/Controllers/BookController.php:117
 * @route '/library/books/{book}/download'
 */
export const download = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/library/books/{book}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BookController::download
 * @see app/Http/Controllers/BookController.php:117
 * @route '/library/books/{book}/download'
 */
download.url = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { book: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    book: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book: typeof args.book === 'object'
                ? args.book.id
                : args.book,
                }

    return download.definition.url
            .replace('{book}', parsedArgs.book.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BookController::download
 * @see app/Http/Controllers/BookController.php:117
 * @route '/library/books/{book}/download'
 */
download.get = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BookController::download
 * @see app/Http/Controllers/BookController.php:117
 * @route '/library/books/{book}/download'
 */
download.head = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BookController::download
 * @see app/Http/Controllers/BookController.php:117
 * @route '/library/books/{book}/download'
 */
    const downloadForm = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BookController::download
 * @see app/Http/Controllers/BookController.php:117
 * @route '/library/books/{book}/download'
 */
        downloadForm.get = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BookController::download
 * @see app/Http/Controllers/BookController.php:117
 * @route '/library/books/{book}/download'
 */
        downloadForm.head = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const books = {
    reader: Object.assign(reader, reader),
read: Object.assign(read, read),
download: Object.assign(download, download),
}

export default books