import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
export const reader = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reader.url(args, options),
    method: 'get',
})

reader.definition = {
    methods: ["get","head"],
    url: '/majalla/{magazine}/reader',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
reader.url = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { magazine: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { magazine: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    magazine: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        magazine: typeof args.magazine === 'object'
                ? args.magazine.id
                : args.magazine,
                }

    return reader.definition.url
            .replace('{magazine}', parsedArgs.magazine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
reader.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reader.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
reader.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reader.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
    const readerForm = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reader.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
        readerForm.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reader.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MagazineController::reader
 * @see app/Http/Controllers/MagazineController.php:51
 * @route '/majalla/{magazine}/reader'
 */
        readerForm.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reader.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reader.form = readerForm
/**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
export const read = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: read.url(args, options),
    method: 'get',
})

read.definition = {
    methods: ["get","head"],
    url: '/majalla/{magazine}/read',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
read.url = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { magazine: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { magazine: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    magazine: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        magazine: typeof args.magazine === 'object'
                ? args.magazine.id
                : args.magazine,
                }

    return read.definition.url
            .replace('{magazine}', parsedArgs.magazine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
read.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: read.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
read.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: read.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
    const readForm = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: read.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
        readForm.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: read.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MagazineController::read
 * @see app/Http/Controllers/MagazineController.php:71
 * @route '/majalla/{magazine}/read'
 */
        readForm.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: read.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    read.form = readForm
/**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
export const download = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/majalla/{magazine}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
download.url = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { magazine: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { magazine: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    magazine: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        magazine: typeof args.magazine === 'object'
                ? args.magazine.id
                : args.magazine,
                }

    return download.definition.url
            .replace('{magazine}', parsedArgs.magazine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
download.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
download.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
    const downloadForm = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
        downloadForm.get = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MagazineController::download
 * @see app/Http/Controllers/MagazineController.php:92
 * @route '/majalla/{magazine}/download'
 */
        downloadForm.head = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const majalla = {
    reader: Object.assign(reader, reader),
read: Object.assign(read, read),
download: Object.assign(download, download),
}

export default majalla