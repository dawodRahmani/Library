import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/magazines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MagazineController::index
 * @see app/Http/Controllers/MagazineController.php:106
 * @route '/admin/magazines'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MagazineController::store
 * @see app/Http/Controllers/MagazineController.php:133
 * @route '/admin/magazines'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/magazines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MagazineController::store
 * @see app/Http/Controllers/MagazineController.php:133
 * @route '/admin/magazines'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::store
 * @see app/Http/Controllers/MagazineController.php:133
 * @route '/admin/magazines'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MagazineController::store
 * @see app/Http/Controllers/MagazineController.php:133
 * @route '/admin/magazines'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MagazineController::store
 * @see app/Http/Controllers/MagazineController.php:133
 * @route '/admin/magazines'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\MagazineController::update
 * @see app/Http/Controllers/MagazineController.php:140
 * @route '/admin/magazines/{magazine}'
 */
export const update = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/magazines/{magazine}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\MagazineController::update
 * @see app/Http/Controllers/MagazineController.php:140
 * @route '/admin/magazines/{magazine}'
 */
update.url = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { magazine: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { magazine: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    magazine: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        magazine: typeof args.magazine === 'object'
                ? args.magazine.id
                : args.magazine,
                }

    return update.definition.url
            .replace('{magazine}', parsedArgs.magazine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::update
 * @see app/Http/Controllers/MagazineController.php:140
 * @route '/admin/magazines/{magazine}'
 */
update.put = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\MagazineController::update
 * @see app/Http/Controllers/MagazineController.php:140
 * @route '/admin/magazines/{magazine}'
 */
    const updateForm = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MagazineController::update
 * @see app/Http/Controllers/MagazineController.php:140
 * @route '/admin/magazines/{magazine}'
 */
        updateForm.put = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\MagazineController::destroy
 * @see app/Http/Controllers/MagazineController.php:147
 * @route '/admin/magazines/{magazine}'
 */
export const destroy = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/magazines/{magazine}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\MagazineController::destroy
 * @see app/Http/Controllers/MagazineController.php:147
 * @route '/admin/magazines/{magazine}'
 */
destroy.url = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { magazine: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { magazine: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    magazine: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        magazine: typeof args.magazine === 'object'
                ? args.magazine.id
                : args.magazine,
                }

    return destroy.definition.url
            .replace('{magazine}', parsedArgs.magazine.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::destroy
 * @see app/Http/Controllers/MagazineController.php:147
 * @route '/admin/magazines/{magazine}'
 */
destroy.delete = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\MagazineController::destroy
 * @see app/Http/Controllers/MagazineController.php:147
 * @route '/admin/magazines/{magazine}'
 */
    const destroyForm = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MagazineController::destroy
 * @see app/Http/Controllers/MagazineController.php:147
 * @route '/admin/magazines/{magazine}'
 */
        destroyForm.delete = (args: { magazine: number | { id: number } } | [magazine: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const magazines = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default magazines