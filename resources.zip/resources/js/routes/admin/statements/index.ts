import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:153
 * @route '/admin/statements'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/statements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:153
 * @route '/admin/statements'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:153
 * @route '/admin/statements'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:153
 * @route '/admin/statements'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:153
 * @route '/admin/statements'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:153
 * @route '/admin/statements'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:153
 * @route '/admin/statements'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:127
 * @route '/admin/statements/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/statements/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:127
 * @route '/admin/statements/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:127
 * @route '/admin/statements/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:127
 * @route '/admin/statements/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:127
 * @route '/admin/statements/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:127
 * @route '/admin/statements/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:127
 * @route '/admin/statements/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\StatementController::edit
 * @see app/Http/Controllers/StatementController.php:133
 * @route '/admin/statements/{statement}/edit'
 */
export const edit = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/statements/{statement}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::edit
 * @see app/Http/Controllers/StatementController.php:133
 * @route '/admin/statements/{statement}/edit'
 */
edit.url = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { statement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { statement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    statement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        statement: typeof args.statement === 'object'
                ? args.statement.id
                : args.statement,
                }

    return edit.definition.url
            .replace('{statement}', parsedArgs.statement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::edit
 * @see app/Http/Controllers/StatementController.php:133
 * @route '/admin/statements/{statement}/edit'
 */
edit.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::edit
 * @see app/Http/Controllers/StatementController.php:133
 * @route '/admin/statements/{statement}/edit'
 */
edit.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::edit
 * @see app/Http/Controllers/StatementController.php:133
 * @route '/admin/statements/{statement}/edit'
 */
    const editForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::edit
 * @see app/Http/Controllers/StatementController.php:133
 * @route '/admin/statements/{statement}/edit'
 */
        editForm.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::edit
 * @see app/Http/Controllers/StatementController.php:133
 * @route '/admin/statements/{statement}/edit'
 */
        editForm.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\StatementController::store
 * @see app/Http/Controllers/StatementController.php:177
 * @route '/admin/statements'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/statements',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StatementController::store
 * @see app/Http/Controllers/StatementController.php:177
 * @route '/admin/statements'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::store
 * @see app/Http/Controllers/StatementController.php:177
 * @route '/admin/statements'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StatementController::store
 * @see app/Http/Controllers/StatementController.php:177
 * @route '/admin/statements'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StatementController::store
 * @see app/Http/Controllers/StatementController.php:177
 * @route '/admin/statements'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\StatementController::update
 * @see app/Http/Controllers/StatementController.php:185
 * @route '/admin/statements/{statement}'
 */
export const update = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/statements/{statement}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\StatementController::update
 * @see app/Http/Controllers/StatementController.php:185
 * @route '/admin/statements/{statement}'
 */
update.url = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { statement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { statement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    statement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        statement: typeof args.statement === 'object'
                ? args.statement.id
                : args.statement,
                }

    return update.definition.url
            .replace('{statement}', parsedArgs.statement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::update
 * @see app/Http/Controllers/StatementController.php:185
 * @route '/admin/statements/{statement}'
 */
update.put = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\StatementController::update
 * @see app/Http/Controllers/StatementController.php:185
 * @route '/admin/statements/{statement}'
 */
    const updateForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StatementController::update
 * @see app/Http/Controllers/StatementController.php:185
 * @route '/admin/statements/{statement}'
 */
        updateForm.put = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\StatementController::destroy
 * @see app/Http/Controllers/StatementController.php:193
 * @route '/admin/statements/{statement}'
 */
export const destroy = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/statements/{statement}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\StatementController::destroy
 * @see app/Http/Controllers/StatementController.php:193
 * @route '/admin/statements/{statement}'
 */
destroy.url = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { statement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { statement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    statement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        statement: typeof args.statement === 'object'
                ? args.statement.id
                : args.statement,
                }

    return destroy.definition.url
            .replace('{statement}', parsedArgs.statement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::destroy
 * @see app/Http/Controllers/StatementController.php:193
 * @route '/admin/statements/{statement}'
 */
destroy.delete = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\StatementController::destroy
 * @see app/Http/Controllers/StatementController.php:193
 * @route '/admin/statements/{statement}'
 */
    const destroyForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StatementController::destroy
 * @see app/Http/Controllers/StatementController.php:193
 * @route '/admin/statements/{statement}'
 */
        destroyForm.delete = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const statements = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
edit: Object.assign(edit, edit),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default statements