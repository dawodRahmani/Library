import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\BackupController::database
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
export const database = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: database.url(options),
    method: 'get',
})

database.definition = {
    methods: ["get","head"],
    url: '/admin/backup/database',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BackupController::database
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
database.url = (options?: RouteQueryOptions) => {
    return database.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BackupController::database
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
database.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: database.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BackupController::database
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
database.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: database.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BackupController::database
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
    const databaseForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: database.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BackupController::database
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
        databaseForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: database.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BackupController::database
 * @see app/Http/Controllers/BackupController.php:19
 * @route '/admin/backup/database'
 */
        databaseForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: database.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    database.form = databaseForm
/**
* @see \App\Http\Controllers\BackupController::images
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
export const images = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: images.url(options),
    method: 'get',
})

images.definition = {
    methods: ["get","head"],
    url: '/admin/backup/images',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BackupController::images
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
images.url = (options?: RouteQueryOptions) => {
    return images.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BackupController::images
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
images.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: images.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BackupController::images
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
images.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: images.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BackupController::images
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
    const imagesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: images.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BackupController::images
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
        imagesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: images.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BackupController::images
 * @see app/Http/Controllers/BackupController.php:34
 * @route '/admin/backup/images'
 */
        imagesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: images.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    images.form = imagesForm
/**
* @see \App\Http\Controllers\BackupController::videos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
export const videos = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: videos.url(options),
    method: 'get',
})

videos.definition = {
    methods: ["get","head"],
    url: '/admin/backup/videos',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\BackupController::videos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
videos.url = (options?: RouteQueryOptions) => {
    return videos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\BackupController::videos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
videos.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: videos.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\BackupController::videos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
videos.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: videos.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\BackupController::videos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
    const videosForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: videos.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\BackupController::videos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
        videosForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: videos.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\BackupController::videos
 * @see app/Http/Controllers/BackupController.php:43
 * @route '/admin/backup/videos'
 */
        videosForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: videos.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    videos.form = videosForm
const backup = {
    database: Object.assign(database, database),
images: Object.assign(images, images),
videos: Object.assign(videos, videos),
}

export default backup