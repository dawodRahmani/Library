import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SiteSettingController::remove
 * @see app/Http/Controllers/SiteSettingController.php:173
 * @route '/admin/site-settings/about-hero'
 */
export const remove = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(options),
    method: 'delete',
})

remove.definition = {
    methods: ["delete"],
    url: '/admin/site-settings/about-hero',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SiteSettingController::remove
 * @see app/Http/Controllers/SiteSettingController.php:173
 * @route '/admin/site-settings/about-hero'
 */
remove.url = (options?: RouteQueryOptions) => {
    return remove.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::remove
 * @see app/Http/Controllers/SiteSettingController.php:173
 * @route '/admin/site-settings/about-hero'
 */
remove.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::remove
 * @see app/Http/Controllers/SiteSettingController.php:173
 * @route '/admin/site-settings/about-hero'
 */
    const removeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: remove.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::remove
 * @see app/Http/Controllers/SiteSettingController.php:173
 * @route '/admin/site-settings/about-hero'
 */
        removeForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: remove.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    remove.form = removeForm
const aboutHero = {
    remove: Object.assign(remove, remove),
}

export default aboutHero