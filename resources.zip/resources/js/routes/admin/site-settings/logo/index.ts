import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SiteSettingController::remove
 * @see app/Http/Controllers/SiteSettingController.php:114
 * @route '/admin/site-settings/logo'
 */
export const remove = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(options),
    method: 'delete',
})

remove.definition = {
    methods: ["delete"],
    url: '/admin/site-settings/logo',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SiteSettingController::remove
 * @see app/Http/Controllers/SiteSettingController.php:114
 * @route '/admin/site-settings/logo'
 */
remove.url = (options?: RouteQueryOptions) => {
    return remove.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::remove
 * @see app/Http/Controllers/SiteSettingController.php:114
 * @route '/admin/site-settings/logo'
 */
remove.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: remove.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::remove
 * @see app/Http/Controllers/SiteSettingController.php:114
 * @route '/admin/site-settings/logo'
 */
    const removeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: remove.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::remove
 * @see app/Http/Controllers/SiteSettingController.php:114
 * @route '/admin/site-settings/logo'
 */
        removeForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: remove.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    remove.form = removeForm
const logo = {
    remove: Object.assign(remove, remove),
}

export default logo