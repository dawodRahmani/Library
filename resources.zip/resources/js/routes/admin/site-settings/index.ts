import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import logo21d67d from './logo'
import contactQr2943e4 from './contact-qr'
import aboutHeroE12a88 from './about-hero'
/**
* @see \App\Http\Controllers\SiteSettingController::index
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/site-settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SiteSettingController::index
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::index
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SiteSettingController::index
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::index
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::index
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SiteSettingController::index
 * @see app/Http/Controllers/SiteSettingController.php:15
 * @route '/admin/site-settings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SiteSettingController::update
 * @see app/Http/Controllers/SiteSettingController.php:22
 * @route '/admin/site-settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/site-settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SiteSettingController::update
 * @see app/Http/Controllers/SiteSettingController.php:22
 * @route '/admin/site-settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::update
 * @see app/Http/Controllers/SiteSettingController.php:22
 * @route '/admin/site-settings'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::update
 * @see app/Http/Controllers/SiteSettingController.php:22
 * @route '/admin/site-settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::update
 * @see app/Http/Controllers/SiteSettingController.php:22
 * @route '/admin/site-settings'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\SiteSettingController::logo
 * @see app/Http/Controllers/SiteSettingController.php:98
 * @route '/admin/site-settings/logo'
 */
export const logo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logo.url(options),
    method: 'post',
})

logo.definition = {
    methods: ["post"],
    url: '/admin/site-settings/logo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SiteSettingController::logo
 * @see app/Http/Controllers/SiteSettingController.php:98
 * @route '/admin/site-settings/logo'
 */
logo.url = (options?: RouteQueryOptions) => {
    return logo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::logo
 * @see app/Http/Controllers/SiteSettingController.php:98
 * @route '/admin/site-settings/logo'
 */
logo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logo.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::logo
 * @see app/Http/Controllers/SiteSettingController.php:98
 * @route '/admin/site-settings/logo'
 */
    const logoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logo.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::logo
 * @see app/Http/Controllers/SiteSettingController.php:98
 * @route '/admin/site-settings/logo'
 */
        logoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logo.url(options),
            method: 'post',
        })
    
    logo.form = logoForm
/**
* @see \App\Http\Controllers\SiteSettingController::contactQr
 * @see app/Http/Controllers/SiteSettingController.php:124
 * @route '/admin/site-settings/contact-qr'
 */
export const contactQr = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: contactQr.url(options),
    method: 'post',
})

contactQr.definition = {
    methods: ["post"],
    url: '/admin/site-settings/contact-qr',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SiteSettingController::contactQr
 * @see app/Http/Controllers/SiteSettingController.php:124
 * @route '/admin/site-settings/contact-qr'
 */
contactQr.url = (options?: RouteQueryOptions) => {
    return contactQr.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::contactQr
 * @see app/Http/Controllers/SiteSettingController.php:124
 * @route '/admin/site-settings/contact-qr'
 */
contactQr.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: contactQr.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::contactQr
 * @see app/Http/Controllers/SiteSettingController.php:124
 * @route '/admin/site-settings/contact-qr'
 */
    const contactQrForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: contactQr.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::contactQr
 * @see app/Http/Controllers/SiteSettingController.php:124
 * @route '/admin/site-settings/contact-qr'
 */
        contactQrForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: contactQr.url(options),
            method: 'post',
        })
    
    contactQr.form = contactQrForm
/**
* @see \App\Http\Controllers\SiteSettingController::aboutHero
 * @see app/Http/Controllers/SiteSettingController.php:155
 * @route '/admin/site-settings/about-hero'
 */
export const aboutHero = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: aboutHero.url(options),
    method: 'post',
})

aboutHero.definition = {
    methods: ["post"],
    url: '/admin/site-settings/about-hero',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SiteSettingController::aboutHero
 * @see app/Http/Controllers/SiteSettingController.php:155
 * @route '/admin/site-settings/about-hero'
 */
aboutHero.url = (options?: RouteQueryOptions) => {
    return aboutHero.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SiteSettingController::aboutHero
 * @see app/Http/Controllers/SiteSettingController.php:155
 * @route '/admin/site-settings/about-hero'
 */
aboutHero.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: aboutHero.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SiteSettingController::aboutHero
 * @see app/Http/Controllers/SiteSettingController.php:155
 * @route '/admin/site-settings/about-hero'
 */
    const aboutHeroForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: aboutHero.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SiteSettingController::aboutHero
 * @see app/Http/Controllers/SiteSettingController.php:155
 * @route '/admin/site-settings/about-hero'
 */
        aboutHeroForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: aboutHero.url(options),
            method: 'post',
        })
    
    aboutHero.form = aboutHeroForm
const siteSettings = {
    index: Object.assign(index, index),
update: Object.assign(update, update),
logo: Object.assign(logo, logo21d67d),
contactQr: Object.assign(contactQr, contactQr2943e4),
aboutHero: Object.assign(aboutHero, aboutHeroE12a88),
}

export default siteSettings