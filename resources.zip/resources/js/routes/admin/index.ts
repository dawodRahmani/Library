import books from './books'
import videos from './videos'
import audios from './audios'
import fatwas from './fatwas'
import statements from './statements'
import magazines from './magazines'
import siteSettings from './site-settings'
import backup from './backup'
import messages from './messages'
import categories from './categories'
const admin = {
    books: Object.assign(books, books),
videos: Object.assign(videos, videos),
audios: Object.assign(audios, audios),
fatwas: Object.assign(fatwas, fatwas),
statements: Object.assign(statements, statements),
magazines: Object.assign(magazines, magazines),
siteSettings: Object.assign(siteSettings, siteSettings),
backup: Object.assign(backup, backup),
messages: Object.assign(messages, messages),
categories: Object.assign(categories, categories),
}

export default admin