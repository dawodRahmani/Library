import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../wayfinder'
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: login.url(options),
        method: 'get',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
        loginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url(options),
            method: 'get',
        })
            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
        loginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    login.form = loginForm
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \App\Http\Controllers\SearchController::search
 * @see app/Http/Controllers/SearchController.php:15
 * @route '/search'
 */
export const search = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

search.definition = {
    methods: ["get","head"],
    url: '/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SearchController::search
 * @see app/Http/Controllers/SearchController.php:15
 * @route '/search'
 */
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SearchController::search
 * @see app/Http/Controllers/SearchController.php:15
 * @route '/search'
 */
search.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SearchController::search
 * @see app/Http/Controllers/SearchController.php:15
 * @route '/search'
 */
search.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SearchController::search
 * @see app/Http/Controllers/SearchController.php:15
 * @route '/search'
 */
    const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: search.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SearchController::search
 * @see app/Http/Controllers/SearchController.php:15
 * @route '/search'
 */
        searchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: search.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SearchController::search
 * @see app/Http/Controllers/SearchController.php:15
 * @route '/search'
 */
        searchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: search.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    search.form = searchForm
/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:16
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:16
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:16
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:16
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:16
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:16
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:16
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\AudioController::audio
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
export const audio = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: audio.url(options),
    method: 'get',
})

audio.definition = {
    methods: ["get","head"],
    url: '/audio',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AudioController::audio
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
audio.url = (options?: RouteQueryOptions) => {
    return audio.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::audio
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
audio.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: audio.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AudioController::audio
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
audio.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: audio.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AudioController::audio
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
    const audioForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: audio.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AudioController::audio
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
        audioForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: audio.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AudioController::audio
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
        audioForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: audio.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    audio.form = audioForm
/**
* @see \App\Http\Controllers\FatwaController::darUlIfta
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
export const darUlIfta = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: darUlIfta.url(options),
    method: 'get',
})

darUlIfta.definition = {
    methods: ["get","head"],
    url: '/dar-ul-ifta',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FatwaController::darUlIfta
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
darUlIfta.url = (options?: RouteQueryOptions) => {
    return darUlIfta.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::darUlIfta
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
darUlIfta.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: darUlIfta.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FatwaController::darUlIfta
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
darUlIfta.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: darUlIfta.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FatwaController::darUlIfta
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
    const darUlIftaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: darUlIfta.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FatwaController::darUlIfta
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
        darUlIftaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: darUlIfta.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FatwaController::darUlIfta
 * @see app/Http/Controllers/FatwaController.php:17
 * @route '/dar-ul-ifta'
 */
        darUlIftaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: darUlIfta.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    darUlIfta.form = darUlIftaForm
/**
* @see \App\Http\Controllers\MagazineController::majalla
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
export const majalla = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: majalla.url(options),
    method: 'get',
})

majalla.definition = {
    methods: ["get","head"],
    url: '/majalla',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MagazineController::majalla
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
majalla.url = (options?: RouteQueryOptions) => {
    return majalla.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MagazineController::majalla
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
majalla.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: majalla.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MagazineController::majalla
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
majalla.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: majalla.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MagazineController::majalla
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
    const majallaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: majalla.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MagazineController::majalla
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
        majallaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: majalla.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MagazineController::majalla
 * @see app/Http/Controllers/MagazineController.php:17
 * @route '/majalla'
 */
        majallaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: majalla.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    majalla.form = majallaForm
/**
* @see \App\Http\Controllers\StatementController::bayania
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
export const bayania = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bayania.url(options),
    method: 'get',
})

bayania.definition = {
    methods: ["get","head"],
    url: '/bayania',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::bayania
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
bayania.url = (options?: RouteQueryOptions) => {
    return bayania.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::bayania
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
bayania.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bayania.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::bayania
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
bayania.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: bayania.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::bayania
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
    const bayaniaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: bayania.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::bayania
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
        bayaniaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bayania.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::bayania
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
        bayaniaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bayania.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    bayania.form = bayaniaForm
/**
 * @see routes/web.php:41
 * @route '/fikr'
 */
export const fikr = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fikr.url(options),
    method: 'get',
})

fikr.definition = {
    methods: ["get","head"],
    url: '/fikr',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:41
 * @route '/fikr'
 */
fikr.url = (options?: RouteQueryOptions) => {
    return fikr.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:41
 * @route '/fikr'
 */
fikr.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: fikr.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:41
 * @route '/fikr'
 */
fikr.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: fikr.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:41
 * @route '/fikr'
 */
    const fikrForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: fikr.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:41
 * @route '/fikr'
 */
        fikrForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: fikr.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:41
 * @route '/fikr'
 */
        fikrForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: fikr.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    fikr.form = fikrForm
/**
 * @see routes/web.php:42
 * @route '/about'
 */
export const about = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})

about.definition = {
    methods: ["get","head"],
    url: '/about',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:42
 * @route '/about'
 */
about.url = (options?: RouteQueryOptions) => {
    return about.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:42
 * @route '/about'
 */
about.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:42
 * @route '/about'
 */
about.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: about.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:42
 * @route '/about'
 */
    const aboutForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: about.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:42
 * @route '/about'
 */
        aboutForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: about.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:42
 * @route '/about'
 */
        aboutForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: about.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    about.form = aboutForm
/**
 * @see routes/web.php:43
 * @route '/contact'
 */
export const contact = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})

contact.definition = {
    methods: ["get","head"],
    url: '/contact',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:43
 * @route '/contact'
 */
contact.url = (options?: RouteQueryOptions) => {
    return contact.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:43
 * @route '/contact'
 */
contact.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:43
 * @route '/contact'
 */
contact.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contact.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:43
 * @route '/contact'
 */
    const contactForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: contact.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:43
 * @route '/contact'
 */
        contactForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contact.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:43
 * @route '/contact'
 */
        contactForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contact.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    contact.form = contactForm
/**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:17
 * @route '/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:17
 * @route '/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:17
 * @route '/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:17
 * @route '/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:17
 * @route '/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:17
 * @route '/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::dashboard
 * @see app/Http/Controllers/DashboardController.php:17
 * @route '/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm