import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
export const stream = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})

stream.definition = {
    methods: ["get","head"],
    url: '/dar-ul-ifta/{fatwa}/stream',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
stream.url = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fatwa: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fatwa: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fatwa: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fatwa: typeof args.fatwa === 'object'
                ? args.fatwa.id
                : args.fatwa,
                }

    return stream.definition.url
            .replace('{fatwa}', parsedArgs.fatwa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
stream.get = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
stream.head = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stream.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
    const streamForm = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stream.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
        streamForm.get = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FatwaController::stream
 * @see app/Http/Controllers/FatwaController.php:61
 * @route '/dar-ul-ifta/{fatwa}/stream'
 */
        streamForm.head = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stream.form = streamForm
const fatwas = {
    stream: Object.assign(stream, stream),
}

export default fatwas