import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
export const show = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/bayania/{statement}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
show.url = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { statement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { statement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    statement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        statement: typeof args.statement === 'object'
                ? args.statement.id
                : args.statement,
                }

    return show.definition.url
            .replace('{statement}', parsedArgs.statement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
show.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
show.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
    const showForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
        showForm.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
        showForm.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
export const stream = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})

stream.definition = {
    methods: ["get","head"],
    url: '/bayania/{statement}/stream',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
stream.url = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { statement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { statement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    statement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        statement: typeof args.statement === 'object'
                ? args.statement.id
                : args.statement,
                }

    return stream.definition.url
            .replace('{statement}', parsedArgs.statement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
stream.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
stream.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stream.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
    const streamForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stream.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
        streamForm.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
        streamForm.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stream.form = streamForm
const bayania = {
    show: Object.assign(show, show),
stream: Object.assign(stream, stream),
}

export default bayania