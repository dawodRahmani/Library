import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
export const stream = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})

stream.definition = {
    methods: ["get","head"],
    url: '/audio/{audio}/stream',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
stream.url = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { audio: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { audio: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    audio: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        audio: typeof args.audio === 'object'
                ? args.audio.id
                : args.audio,
                }

    return stream.definition.url
            .replace('{audio}', parsedArgs.audio.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
stream.get = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
stream.head = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stream.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
    const streamForm = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stream.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
        streamForm.get = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
        streamForm.head = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stream.form = streamForm
/**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
export const download = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/audio/{audio}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
download.url = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { audio: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { audio: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    audio: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        audio: typeof args.audio === 'object'
                ? args.audio.id
                : args.audio,
                }

    return download.definition.url
            .replace('{audio}', parsedArgs.audio.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
download.get = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
download.head = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
    const downloadForm = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
        downloadForm.get = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
        downloadForm.head = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const audio = {
    stream: Object.assign(stream, stream),
download: Object.assign(download, download),
}

export default audio