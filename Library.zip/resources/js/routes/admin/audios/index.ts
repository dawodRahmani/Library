import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/audios',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AudioController::store
 * @see app/Http/Controllers/AudioController.php:194
 * @route '/admin/audios'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/audios',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AudioController::store
 * @see app/Http/Controllers/AudioController.php:194
 * @route '/admin/audios'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::store
 * @see app/Http/Controllers/AudioController.php:194
 * @route '/admin/audios'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AudioController::store
 * @see app/Http/Controllers/AudioController.php:194
 * @route '/admin/audios'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AudioController::store
 * @see app/Http/Controllers/AudioController.php:194
 * @route '/admin/audios'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AudioController::update
 * @see app/Http/Controllers/AudioController.php:201
 * @route '/admin/audios/{audio}'
 */
export const update = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/audios/{audio}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AudioController::update
 * @see app/Http/Controllers/AudioController.php:201
 * @route '/admin/audios/{audio}'
 */
update.url = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { audio: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { audio: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    audio: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        audio: typeof args.audio === 'object'
                ? args.audio.id
                : args.audio,
                }

    return update.definition.url
            .replace('{audio}', parsedArgs.audio.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::update
 * @see app/Http/Controllers/AudioController.php:201
 * @route '/admin/audios/{audio}'
 */
update.put = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AudioController::update
 * @see app/Http/Controllers/AudioController.php:201
 * @route '/admin/audios/{audio}'
 */
    const updateForm = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AudioController::update
 * @see app/Http/Controllers/AudioController.php:201
 * @route '/admin/audios/{audio}'
 */
        updateForm.put = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AudioController::destroy
 * @see app/Http/Controllers/AudioController.php:208
 * @route '/admin/audios/{audio}'
 */
export const destroy = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/audios/{audio}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AudioController::destroy
 * @see app/Http/Controllers/AudioController.php:208
 * @route '/admin/audios/{audio}'
 */
destroy.url = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { audio: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { audio: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    audio: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        audio: typeof args.audio === 'object'
                ? args.audio.id
                : args.audio,
                }

    return destroy.definition.url
            .replace('{audio}', parsedArgs.audio.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::destroy
 * @see app/Http/Controllers/AudioController.php:208
 * @route '/admin/audios/{audio}'
 */
destroy.delete = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AudioController::destroy
 * @see app/Http/Controllers/AudioController.php:208
 * @route '/admin/audios/{audio}'
 */
    const destroyForm = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AudioController::destroy
 * @see app/Http/Controllers/AudioController.php:208
 * @route '/admin/audios/{audio}'
 */
        destroyForm.delete = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const audios = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default audios