import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ChunkUploadController::chunk
 * @see app/Http/Controllers/ChunkUploadController.php:20
 * @route '/admin/uploads/chunk'
 */
export const chunk = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: chunk.url(options),
    method: 'post',
})

chunk.definition = {
    methods: ["post"],
    url: '/admin/uploads/chunk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChunkUploadController::chunk
 * @see app/Http/Controllers/ChunkUploadController.php:20
 * @route '/admin/uploads/chunk'
 */
chunk.url = (options?: RouteQueryOptions) => {
    return chunk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChunkUploadController::chunk
 * @see app/Http/Controllers/ChunkUploadController.php:20
 * @route '/admin/uploads/chunk'
 */
chunk.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: chunk.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChunkUploadController::chunk
 * @see app/Http/Controllers/ChunkUploadController.php:20
 * @route '/admin/uploads/chunk'
 */
    const chunkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: chunk.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChunkUploadController::chunk
 * @see app/Http/Controllers/ChunkUploadController.php:20
 * @route '/admin/uploads/chunk'
 */
        chunkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: chunk.url(options),
            method: 'post',
        })
    
    chunk.form = chunkForm
const uploads = {
    chunk: Object.assign(chunk, chunk),
}

export default uploads