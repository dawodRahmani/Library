import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:137
 * @route '/admin/fatwas'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/fatwas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:137
 * @route '/admin/fatwas'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:137
 * @route '/admin/fatwas'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:137
 * @route '/admin/fatwas'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:137
 * @route '/admin/fatwas'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:137
 * @route '/admin/fatwas'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\FatwaController::index
 * @see app/Http/Controllers/FatwaController.php:137
 * @route '/admin/fatwas'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\FatwaController::store
 * @see app/Http/Controllers/FatwaController.php:173
 * @route '/admin/fatwas'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/fatwas',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FatwaController::store
 * @see app/Http/Controllers/FatwaController.php:173
 * @route '/admin/fatwas'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::store
 * @see app/Http/Controllers/FatwaController.php:173
 * @route '/admin/fatwas'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\FatwaController::store
 * @see app/Http/Controllers/FatwaController.php:173
 * @route '/admin/fatwas'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FatwaController::store
 * @see app/Http/Controllers/FatwaController.php:173
 * @route '/admin/fatwas'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\FatwaController::update
 * @see app/Http/Controllers/FatwaController.php:180
 * @route '/admin/fatwas/{fatwa}'
 */
export const update = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/fatwas/{fatwa}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FatwaController::update
 * @see app/Http/Controllers/FatwaController.php:180
 * @route '/admin/fatwas/{fatwa}'
 */
update.url = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fatwa: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fatwa: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fatwa: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fatwa: typeof args.fatwa === 'object'
                ? args.fatwa.id
                : args.fatwa,
                }

    return update.definition.url
            .replace('{fatwa}', parsedArgs.fatwa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::update
 * @see app/Http/Controllers/FatwaController.php:180
 * @route '/admin/fatwas/{fatwa}'
 */
update.put = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\FatwaController::update
 * @see app/Http/Controllers/FatwaController.php:180
 * @route '/admin/fatwas/{fatwa}'
 */
    const updateForm = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FatwaController::update
 * @see app/Http/Controllers/FatwaController.php:180
 * @route '/admin/fatwas/{fatwa}'
 */
        updateForm.put = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\FatwaController::destroy
 * @see app/Http/Controllers/FatwaController.php:280
 * @route '/admin/fatwas/{fatwa}'
 */
export const destroy = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/fatwas/{fatwa}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\FatwaController::destroy
 * @see app/Http/Controllers/FatwaController.php:280
 * @route '/admin/fatwas/{fatwa}'
 */
destroy.url = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { fatwa: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { fatwa: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    fatwa: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        fatwa: typeof args.fatwa === 'object'
                ? args.fatwa.id
                : args.fatwa,
                }

    return destroy.definition.url
            .replace('{fatwa}', parsedArgs.fatwa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FatwaController::destroy
 * @see app/Http/Controllers/FatwaController.php:280
 * @route '/admin/fatwas/{fatwa}'
 */
destroy.delete = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\FatwaController::destroy
 * @see app/Http/Controllers/FatwaController.php:280
 * @route '/admin/fatwas/{fatwa}'
 */
    const destroyForm = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\FatwaController::destroy
 * @see app/Http/Controllers/FatwaController.php:280
 * @route '/admin/fatwas/{fatwa}'
 */
        destroyForm.delete = (args: { fatwa: number | { id: number } } | [fatwa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const fatwas = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default fatwas