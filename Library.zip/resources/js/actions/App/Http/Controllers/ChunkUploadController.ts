import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ChunkUploadController::store
 * @see app/Http/Controllers/ChunkUploadController.php:20
 * @route '/admin/uploads/chunk'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/uploads/chunk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChunkUploadController::store
 * @see app/Http/Controllers/ChunkUploadController.php:20
 * @route '/admin/uploads/chunk'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChunkUploadController::store
 * @see app/Http/Controllers/ChunkUploadController.php:20
 * @route '/admin/uploads/chunk'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChunkUploadController::store
 * @see app/Http/Controllers/ChunkUploadController.php:20
 * @route '/admin/uploads/chunk'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChunkUploadController::store
 * @see app/Http/Controllers/ChunkUploadController.php:20
 * @route '/admin/uploads/chunk'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const ChunkUploadController = { store }

export default ChunkUploadController