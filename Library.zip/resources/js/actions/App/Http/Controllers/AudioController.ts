import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/audio',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AudioController::index
 * @see app/Http/Controllers/AudioController.php:18
 * @route '/audio'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
export const stream = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})

stream.definition = {
    methods: ["get","head"],
    url: '/audio/{audio}/stream',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
stream.url = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { audio: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { audio: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    audio: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        audio: typeof args.audio === 'object'
                ? args.audio.id
                : args.audio,
                }

    return stream.definition.url
            .replace('{audio}', parsedArgs.audio.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
stream.get = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
stream.head = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stream.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
    const streamForm = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stream.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
        streamForm.get = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AudioController::stream
 * @see app/Http/Controllers/AudioController.php:59
 * @route '/audio/{audio}/stream'
 */
        streamForm.head = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stream.form = streamForm
/**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
export const download = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/audio/{audio}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
download.url = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { audio: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { audio: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    audio: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        audio: typeof args.audio === 'object'
                ? args.audio.id
                : args.audio,
                }

    return download.definition.url
            .replace('{audio}', parsedArgs.audio.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
download.get = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
download.head = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
    const downloadForm = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
        downloadForm.get = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AudioController::download
 * @see app/Http/Controllers/AudioController.php:114
 * @route '/audio/{audio}/download'
 */
        downloadForm.head = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
/**
* @see \App\Http\Controllers\AudioController::adminIndex
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
export const adminIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})

adminIndex.definition = {
    methods: ["get","head"],
    url: '/admin/audios',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AudioController::adminIndex
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
adminIndex.url = (options?: RouteQueryOptions) => {
    return adminIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::adminIndex
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
adminIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AudioController::adminIndex
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
adminIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AudioController::adminIndex
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
    const adminIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AudioController::adminIndex
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
        adminIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AudioController::adminIndex
 * @see app/Http/Controllers/AudioController.php:159
 * @route '/admin/audios'
 */
        adminIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminIndex.form = adminIndexForm
/**
* @see \App\Http\Controllers\AudioController::store
 * @see app/Http/Controllers/AudioController.php:194
 * @route '/admin/audios'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/audios',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AudioController::store
 * @see app/Http/Controllers/AudioController.php:194
 * @route '/admin/audios'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::store
 * @see app/Http/Controllers/AudioController.php:194
 * @route '/admin/audios'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AudioController::store
 * @see app/Http/Controllers/AudioController.php:194
 * @route '/admin/audios'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AudioController::store
 * @see app/Http/Controllers/AudioController.php:194
 * @route '/admin/audios'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AudioController::update
 * @see app/Http/Controllers/AudioController.php:201
 * @route '/admin/audios/{audio}'
 */
export const update = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/audios/{audio}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AudioController::update
 * @see app/Http/Controllers/AudioController.php:201
 * @route '/admin/audios/{audio}'
 */
update.url = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { audio: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { audio: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    audio: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        audio: typeof args.audio === 'object'
                ? args.audio.id
                : args.audio,
                }

    return update.definition.url
            .replace('{audio}', parsedArgs.audio.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::update
 * @see app/Http/Controllers/AudioController.php:201
 * @route '/admin/audios/{audio}'
 */
update.put = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AudioController::update
 * @see app/Http/Controllers/AudioController.php:201
 * @route '/admin/audios/{audio}'
 */
    const updateForm = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AudioController::update
 * @see app/Http/Controllers/AudioController.php:201
 * @route '/admin/audios/{audio}'
 */
        updateForm.put = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AudioController::destroy
 * @see app/Http/Controllers/AudioController.php:208
 * @route '/admin/audios/{audio}'
 */
export const destroy = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/audios/{audio}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AudioController::destroy
 * @see app/Http/Controllers/AudioController.php:208
 * @route '/admin/audios/{audio}'
 */
destroy.url = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { audio: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { audio: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    audio: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        audio: typeof args.audio === 'object'
                ? args.audio.id
                : args.audio,
                }

    return destroy.definition.url
            .replace('{audio}', parsedArgs.audio.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AudioController::destroy
 * @see app/Http/Controllers/AudioController.php:208
 * @route '/admin/audios/{audio}'
 */
destroy.delete = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AudioController::destroy
 * @see app/Http/Controllers/AudioController.php:208
 * @route '/admin/audios/{audio}'
 */
    const destroyForm = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AudioController::destroy
 * @see app/Http/Controllers/AudioController.php:208
 * @route '/admin/audios/{audio}'
 */
        destroyForm.delete = (args: { audio: number | { id: number } } | [audio: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const AudioController = { index, stream, download, adminIndex, store, update, destroy }

export default AudioController