import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/bayania',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::index
 * @see app/Http/Controllers/StatementController.php:16
 * @route '/bayania'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
export const show = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/bayania/{statement}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
show.url = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { statement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { statement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    statement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        statement: typeof args.statement === 'object'
                ? args.statement.id
                : args.statement,
                }

    return show.definition.url
            .replace('{statement}', parsedArgs.statement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
show.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
show.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
    const showForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
        showForm.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::show
 * @see app/Http/Controllers/StatementController.php:49
 * @route '/bayania/{statement}'
 */
        showForm.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
export const stream = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})

stream.definition = {
    methods: ["get","head"],
    url: '/bayania/{statement}/stream',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
stream.url = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { statement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { statement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    statement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        statement: typeof args.statement === 'object'
                ? args.statement.id
                : args.statement,
                }

    return stream.definition.url
            .replace('{statement}', parsedArgs.statement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
stream.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
stream.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stream.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
    const streamForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stream.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
        streamForm.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::stream
 * @see app/Http/Controllers/StatementController.php:74
 * @route '/bayania/{statement}/stream'
 */
        streamForm.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stream.form = streamForm
/**
* @see \App\Http\Controllers\StatementController::adminIndex
 * @see app/Http/Controllers/StatementController.php:176
 * @route '/admin/statements'
 */
export const adminIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})

adminIndex.definition = {
    methods: ["get","head"],
    url: '/admin/statements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::adminIndex
 * @see app/Http/Controllers/StatementController.php:176
 * @route '/admin/statements'
 */
adminIndex.url = (options?: RouteQueryOptions) => {
    return adminIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::adminIndex
 * @see app/Http/Controllers/StatementController.php:176
 * @route '/admin/statements'
 */
adminIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adminIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::adminIndex
 * @see app/Http/Controllers/StatementController.php:176
 * @route '/admin/statements'
 */
adminIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adminIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::adminIndex
 * @see app/Http/Controllers/StatementController.php:176
 * @route '/admin/statements'
 */
    const adminIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adminIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::adminIndex
 * @see app/Http/Controllers/StatementController.php:176
 * @route '/admin/statements'
 */
        adminIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::adminIndex
 * @see app/Http/Controllers/StatementController.php:176
 * @route '/admin/statements'
 */
        adminIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adminIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adminIndex.form = adminIndexForm
/**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:150
 * @route '/admin/statements/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/statements/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:150
 * @route '/admin/statements/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:150
 * @route '/admin/statements/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:150
 * @route '/admin/statements/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:150
 * @route '/admin/statements/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:150
 * @route '/admin/statements/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::create
 * @see app/Http/Controllers/StatementController.php:150
 * @route '/admin/statements/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\StatementController::editForm
 * @see app/Http/Controllers/StatementController.php:156
 * @route '/admin/statements/{statement}/edit'
 */
export const editForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editForm.url(args, options),
    method: 'get',
})

editForm.definition = {
    methods: ["get","head"],
    url: '/admin/statements/{statement}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StatementController::editForm
 * @see app/Http/Controllers/StatementController.php:156
 * @route '/admin/statements/{statement}/edit'
 */
editForm.url = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { statement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { statement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    statement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        statement: typeof args.statement === 'object'
                ? args.statement.id
                : args.statement,
                }

    return editForm.definition.url
            .replace('{statement}', parsedArgs.statement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::editForm
 * @see app/Http/Controllers/StatementController.php:156
 * @route '/admin/statements/{statement}/edit'
 */
editForm.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editForm.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StatementController::editForm
 * @see app/Http/Controllers/StatementController.php:156
 * @route '/admin/statements/{statement}/edit'
 */
editForm.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editForm.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StatementController::editForm
 * @see app/Http/Controllers/StatementController.php:156
 * @route '/admin/statements/{statement}/edit'
 */
    const editFormForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: editForm.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StatementController::editForm
 * @see app/Http/Controllers/StatementController.php:156
 * @route '/admin/statements/{statement}/edit'
 */
        editFormForm.get = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editForm.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StatementController::editForm
 * @see app/Http/Controllers/StatementController.php:156
 * @route '/admin/statements/{statement}/edit'
 */
        editFormForm.head = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editForm.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    editForm.form = editFormForm
/**
* @see \App\Http\Controllers\StatementController::store
 * @see app/Http/Controllers/StatementController.php:200
 * @route '/admin/statements'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/statements',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StatementController::store
 * @see app/Http/Controllers/StatementController.php:200
 * @route '/admin/statements'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::store
 * @see app/Http/Controllers/StatementController.php:200
 * @route '/admin/statements'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StatementController::store
 * @see app/Http/Controllers/StatementController.php:200
 * @route '/admin/statements'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StatementController::store
 * @see app/Http/Controllers/StatementController.php:200
 * @route '/admin/statements'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\StatementController::update
 * @see app/Http/Controllers/StatementController.php:208
 * @route '/admin/statements/{statement}'
 */
export const update = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/statements/{statement}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\StatementController::update
 * @see app/Http/Controllers/StatementController.php:208
 * @route '/admin/statements/{statement}'
 */
update.url = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { statement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { statement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    statement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        statement: typeof args.statement === 'object'
                ? args.statement.id
                : args.statement,
                }

    return update.definition.url
            .replace('{statement}', parsedArgs.statement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::update
 * @see app/Http/Controllers/StatementController.php:208
 * @route '/admin/statements/{statement}'
 */
update.put = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\StatementController::update
 * @see app/Http/Controllers/StatementController.php:208
 * @route '/admin/statements/{statement}'
 */
    const updateForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StatementController::update
 * @see app/Http/Controllers/StatementController.php:208
 * @route '/admin/statements/{statement}'
 */
        updateForm.put = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\StatementController::destroy
 * @see app/Http/Controllers/StatementController.php:216
 * @route '/admin/statements/{statement}'
 */
export const destroy = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/statements/{statement}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\StatementController::destroy
 * @see app/Http/Controllers/StatementController.php:216
 * @route '/admin/statements/{statement}'
 */
destroy.url = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { statement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { statement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    statement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        statement: typeof args.statement === 'object'
                ? args.statement.id
                : args.statement,
                }

    return destroy.definition.url
            .replace('{statement}', parsedArgs.statement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StatementController::destroy
 * @see app/Http/Controllers/StatementController.php:216
 * @route '/admin/statements/{statement}'
 */
destroy.delete = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\StatementController::destroy
 * @see app/Http/Controllers/StatementController.php:216
 * @route '/admin/statements/{statement}'
 */
    const destroyForm = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StatementController::destroy
 * @see app/Http/Controllers/StatementController.php:216
 * @route '/admin/statements/{statement}'
 */
        destroyForm.delete = (args: { statement: number | { id: number } } | [statement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const StatementController = { index, show, stream, adminIndex, create, editForm, store, update, destroy }

export default StatementController